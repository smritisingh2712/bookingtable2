const express = require('express');
const router = express.Router()
const { getoneuserbooking, restourentbook, getonebookingdetails } = require('../controller/book')


router.route('/user/bookings/:userid').get(getoneuserbooking)
router.route('book').post(restourentbook)
router.route('/ bookings/:bookingid').get(getonebookingdetails)



module.exports = router;