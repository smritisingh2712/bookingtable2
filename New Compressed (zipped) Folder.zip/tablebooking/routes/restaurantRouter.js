const express = require('express');
const router = express.Router()
const { createRestaurant, createTable, getrestaurant } = require('../controller/restourentcontroller')


router.route('/restaurant').post(createRestaurant)
router.route('/table').post(createTable)
router.route('/restaurant/:restaurantid').get(getrestaurant)



module.exports = router;