const express = require('express');
const router = express.Router()
const { createuser, getuser, getoneuserbooking } = require('../controller/usercontroller')

//router.get('/', getAllTask)
router.route('/user').post(createuser)
router.route('/user/:userid').get(getuser)
router.route('/user/bookings/:userid').get(getoneuserbooking)



module.exports = router;