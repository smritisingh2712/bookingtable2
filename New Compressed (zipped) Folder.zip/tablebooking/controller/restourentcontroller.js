const Restaurant = require('../models/restaurant')
const Table = require('../models/table')
const User = require('../models/user')

const createRestaurant = async (req, res) => {
    try {
        const newRestaurant = new Restaurant(req.body);
        let saveRestaurnt = await newRestaurant.save();
        res.status(200).json(saveRestaurnt);
    } catch (err) {
        res.status(500).send(err.message);
    }
}



const createTable = async (req, res) => {
    //check if user is owner of restaurant mention in body
    try {
        const newTable = new Table(req.body);
        let saveTable = await newTable.save();
        res.status(200).json(saveTable);
    } catch (err) {
        res.status(500).send(err.message);
    }
}
const getrestaurant = async (req, res) => {
    const restaurantId = req.params.restaurantid;
    let foundRestaurant = await Restaurant.findById(restaurantId);
    if (foundRestaurant) {
        res.status(200).json(foundRestaurant)
    } else {
        res.status(400).json({ message: "Not Found" })
    }
}



module.exports = { createRestaurant, createTable, getrestaurant, }