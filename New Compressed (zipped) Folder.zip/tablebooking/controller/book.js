const User = require('../models/user')
const Booking = require('../models/booking')
const Restaurant = require('../models/restaurant')
const Table = require('../models/table')

const getoneuserbooking = async (req, res) => {
    const userId = req.params.userid;
    let foundBooking = await Booking.find({ user_id: userId });
    if (foundBooking) {
        res.status(200).json(foundBooking)
    } else {
        res.status(400).json({ message: "Not Found" })
    }
}



const restourentbook = async (req, res) => {
    const bookObject = req.body;
    const restaurant = await Restaurant.findById(bookObject.restaurant_id);
    const requestedDay = req.body.day;
    const restaurantOpen = restaurant.working_hrs[requestedDay].start;
    const restaurantClose = restaurant.working_hrs[requestedDay].end;

    if (bookObject.start >= restaurantOpen && bookObject.end <= restaurantClose) {
        const restaurantTables = await Table.find({ restaurant_id: bookObject.restaurant_id, 'capacity': { $gte: bookObject.capacity } });

        if (restaurantTables.length > 0) {
            const bookedTablesInThisTimeRange = await Booking.find({
                day: requestedDay, restaurant_id: bookObject.restaurant_id,
                $and: [
                    { 'start': { $lt: bookObject.end } },
                    { 'end': { $gt: bookObject.start } }
                ]
            });

            const freeTables = [];
            restaurantTables.forEach((table) => {
                if (!bookedTablesInThisTimeRange.some(bookedTable => bookedTable.table_id === table._id.toString())) {
                    freeTables.push(table);
                }
            });
            if (freeTables.length < 1) {
                res.status(400).send(`Sorry!! All tables booked in this time range`);
            }

            const newBooking = new Booking({ ...req.body, table_id: freeTables[0].id });
            let saveBooking = await newBooking.save();
            res.status(200).json(saveBooking);

        } else {
            res.status(400).send(`Sorry!! No tables found for this restaurant. Try to reduce capacity according to tables`);
        }
    } else {
        res.status(400).send(`Please book b/w timings ${restaurantOpen} to ${restaurantClose}`);
    }
}

const getonebookingdetails = async (req, res) => {
    const bookingId = req.params.bookingid;
    let foundBooking = await Booking.findById(bookingId);
    if (foundBooking) {
        res.status(200).json(foundBooking)
    } else {
        res.status(400).json({ message: "Not Found" })
    }
}


module.exports = { getoneuserbooking, restourentbook, getonebookingdetails }