const express = require('express')
const app = express()
const userRouter = require('./routes/userRoutes')
const restaurantRouter = require('./routes/restaurantRouter')
const bookingRouter = require('./routes/bookRouter')
const connectDatabse = require('./db/connect')
require('dotenv').config()
const notfound = require('./middleware/notfound')

//middleware
app.use(express.json())
app.get('/api/v1/', async (req, res) => {
    res.send("Hey")
})
app.use('/api/v1/', userRouter)
app.use('/api/v1/', restaurantRouter)
app.use('/api/v1/', bookingRouter)


app.use(notfound)

const port = process.env.PORT || 3000 //TOCJECK NODE.APP.JS PORT=ANYTHG 

const start = async () => {
    try {
        await connectDatabse(process.env.MONGO_URL)
        app.listen(port, () => console.log(`app is listning from port ${port}...`))


    }
    catch (err) {
        console.log(err)


    }
}
start()

